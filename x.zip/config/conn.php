
<?php
error_reporting(E_ALL & ~E_NOTICE);
date_default_timezone_set('Asia/Jakarta');
$HOST = 'localhost';
$DB_USER = 'root';
$DB_PASSWORD = '';
$DB_NAME = 'sari';

define ("HOST",$HOST);
define ("DB_USER",$DB_USER);
define ("DB_PASSWORD",$DB_PASSWORD);
define ("DB_NAME",$DB_NAME);
define ("BASE_URL","");
$db = mysqli_connect($HOST, $DB_USER, $DB_PASSWORD, $DB_NAME);
if (!$db) {
	die(mysqli_error($db));
}
//SET GMT Buat Tanggal
date_default_timezone_set('Asia/Jakarta');

//FUNGSI ENCRYPT
function enurl($str){
	$encrypted_string=openssl_encrypt($str,"AES-128-ECB",'ajsduyasgdasdvabnsdv');
	return base64_encode($encrypted_string);
}
function deurl($str){
	$decrypted_string=openssl_decrypt(base64_decode($str),"AES-128-ECB",'ajsduyasgdasdvabnsdv');
	return $decrypted_string;
}
$tanggal = date("Y-m-d H:i:s");
$url =  "{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";
$param = parse_url($url, PHP_URL_QUERY);

function Connect(){
    $connect = mysqli_connect(HOST, DB_USER, DB_PASSWORD,DB_NAME);
    if($connect){
        return $connect;
    } else {
      return FALSE;
    }
}
?>

